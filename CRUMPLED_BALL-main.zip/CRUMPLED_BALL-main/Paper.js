class Paper{
constructor(x,y){


}

}